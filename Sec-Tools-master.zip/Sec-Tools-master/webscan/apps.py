from django.apps import AppConfig


class WebscanConfig(AppConfig):
    name = 'webscan'


