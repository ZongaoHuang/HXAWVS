from django.apps import AppConfig


class WebscanBackendConfig(AppConfig):
    name = 'webscan_backend'
