from django.apps import AppConfig


class VulnscanConfig(AppConfig):
    name = 'vulnscan'
